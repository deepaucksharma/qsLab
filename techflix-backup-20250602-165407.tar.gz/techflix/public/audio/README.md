# TechFlix Sound Effects

This directory contains sound effects for the TechFlix application.

## Required Sound Files

Place the following sound files in this directory:

### Essential Sounds
- `netflix-tadum.mp3` - The iconic Netflix "ta-dum" sound (2-3 seconds)
- `episode-start.mp3` - Sound for when episode starts playing
- `whoosh.mp3` - Transition/swoosh sound effect
- `click.mp3` - UI click sound (short, subtle)
- `hover.mp3` - Hover sound effect (very subtle)

### Additional Sounds
- `success.mp3` - Success/completion sound (quiz correct, etc.)
- `error.mp3` - Error/incorrect sound
- `transition.mp3` - Scene transition sound
- `scene-change.mp3` - Scene change notification

## Sound Specifications

- **Format**: MP3 or OGG
- **Quality**: 128-192 kbps
- **Volume**: Normalized to -12dB
- **Duration**: 
  - Click/hover: < 0.5 seconds
  - Transitions: 1-2 seconds
  - Ta-dum: 2-3 seconds

## Creating Placeholder Sounds

For development, you can use these free sound resources:
- [Freesound.org](https://freesound.org)
- [Zapsplat](https://www.zapsplat.com)
- [Free Music Archive](https://freemusicarchive.org)

Or generate simple tones using Web Audio API or online tone generators.

## Netflix Ta-Dum Alternative

If you can't use the actual Netflix sound, create a similar dramatic orchestral hit:
- Two-note progression (like "TA-DUM")
- Deep, resonant tones
- Duration: 2-3 seconds
- Fade out at the end