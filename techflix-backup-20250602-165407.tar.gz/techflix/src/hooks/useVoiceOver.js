/**
 * Voice-over hook for episode scenes
 * Provides compatibility layer for components using the old voice-over API
 */

import { useEffect, useRef, useState } from 'react'
import audioManager from '../utils/audioManager'
import logger from '../utils/logger'

export const useVoiceOver = (episodeId, sceneId, options = {}) => {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const voiceoverRef = useRef(null)
  
  useEffect(() => {
    if (!episodeId || !sceneId || !options.enabled) {
      return
    }
    
    // Load episode audio if needed
    const loadAndPlay = async () => {
      try {
        setIsLoading(true)
        await audioManager.loadEpisodeAudio(episodeId)
        
        if (options.autoPlay) {
          const voiceoverId = `${episodeId}/${sceneId}`
          await audioManager.playVoiceover(voiceoverId, {
            volume: options.volume || audioManager.voiceoverVolume
          })
          setIsPlaying(true)
        }
      } catch (error) {
        logger.error('Failed to load/play voiceover', { episodeId, sceneId, error })
        if (options.onError) {
          options.onError(error)
        }
      } finally {
        setIsLoading(false)
      }
    }
    
    loadAndPlay()
    
    return () => {
      // Cleanup
      if (voiceoverRef.current) {
        voiceoverRef.current.pause()
      }
    }
  }, [episodeId, sceneId, options.enabled, options.autoPlay])
  
  // Control methods
  const play = async () => {
    if (!episodeId || !sceneId) return
    
    try {
      const voiceoverId = `${episodeId}/${sceneId}`
      await audioManager.playVoiceover(voiceoverId)
      setIsPlaying(true)
    } catch (error) {
      logger.error('Failed to play voiceover', { error })
    }
  }
  
  const pause = () => {
    if (voiceoverRef.current) {
      voiceoverRef.current.pause()
      setIsPlaying(false)
    }
  }
  
  const stop = () => {
    if (voiceoverRef.current) {
      voiceoverRef.current.pause()
      voiceoverRef.current.currentTime = 0
      setIsPlaying(false)
    }
  }
  
  return {
    isPlaying,
    isLoading,
    play,
    pause,
    stop,
    volume: options.volume || audioManager.voiceoverVolume
  }
}