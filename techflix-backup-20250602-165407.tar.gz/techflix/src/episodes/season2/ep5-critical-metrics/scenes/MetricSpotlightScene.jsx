import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import AnimatedMetricCounter from '../../../../components/AnimatedMetricCounter';
import '../../../../styles/techflix-cinematic-v2.css';

const MetricSpotlightScene = ({ time = 0, duration = 15 }) => {
  const [activeMetric, setActiveMetric] = useState(0);
  
  // Phase calculation
  const phase = time < 2 ? 'intro' : 
                time < 10 ? 'deepDive' : 
                time < 13 ? 'comparison' : 'revelation';
  
  useEffect(() => {
    if (phase === 'deepDive') {
      const localTime = time - 2;
      const metricIndex = Math.floor(localTime / 2) % 4;
      setActiveMetric(metricIndex);
    }
  }, [phase, time]);
  
  const shareGroupMetrics = [
    {
      name: 'records-unacknowledged-age-ms',
      description: 'Age of oldest unacknowledged record',
      importance: 'Critical for SLA monitoring',
      value: 250,
      unit: 'ms',
      trend: -15
    },
    {
      name: 'redelivery-count',
      description: 'Number of message redeliveries',
      importance: 'Indicates processing failures',
      value: 42,
      unit: 'count',
      trend: 8
    },
    {
      name: 'max-lock-duration-ms',
      description: 'Maximum time a record is locked',
      importance: 'Shows processing bottlenecks',
      value: 1800,
      unit: 'ms',
      trend: -5
    },
    {
      name: 'partition-load-distribution',
      description: 'Balance across consumers',
      importance: 'Ensures even processing',
      value: 94,
      unit: '%',
      trend: 3
    }
  ];
  
  const currentMetric = shareGroupMetrics[activeMetric];
  
  return (
    <div className="scene-container-v2">
      <div className="scene-content">
        <div className="flex flex-col items-center justify-center min-h-full py-12">
          
          {/* Intro Phase */}
          <AnimatePresence>
            {phase === 'intro' && (
              <motion.div
                className="text-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
              >
                <motion.h1
                  className="scene-title text-6xl md:text-8xl mb-6"
                  animate={{
                    backgroundImage: [
                      'linear-gradient(45deg, #3b82f6 0%, #10b981 100%)',
                      'linear-gradient(45deg, #10b981 0%, #f59e0b 100%)',
                      'linear-gradient(45deg, #f59e0b 0%, #3b82f6 100%)'
                    ]
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                  style={{
                    WebkitBackgroundClip: 'text',
                    backgroundClip: 'text',
                    WebkitTextFillColor: 'transparent'
                  }}
                >
                  METRICS SPOTLIGHT
                </motion.h1>
                <p className="scene-subtitle">
                  Deep dive into Share Group observability
                </p>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Deep Dive Phase */}
          <AnimatePresence>
            {phase === 'deepDive' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-full max-w-7xl mx-auto"
              >
                <h2 className="scene-title text-3xl md:text-4xl mb-8 text-center">
                  Share Group Metric Deep Dive
                </h2>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Metric Carousel */}
                  <div className="space-y-6">
                    {shareGroupMetrics.map((metric, index) => (
                      <motion.div
                        key={metric.name}
                        className={`metric-card-v2 p-6 cursor-pointer transition-all duration-300 ${
                          activeMetric === index ? 'border-blue-500' : ''
                        }`}
                        animate={{
                          scale: activeMetric === index ? 1.02 : 1
                        }}
                        onClick={() => setActiveMetric(index)}
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-xl font-mono text-blue-400">
                              {metric.name}
                            </h3>
                            <p className="text-sm text-gray-400 mt-1">
                              {metric.description}
                            </p>
                          </div>
                          <AnimatedMetricCounter
                            value={activeMetric === index ? metric.value : 0}
                            suffix={metric.unit}
                            className="metric-value text-3xl"
                            duration={1000}
                          />
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-500">
                            {metric.importance}
                          </span>
                          <span className={`text-sm font-bold ${
                            metric.trend > 0 ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {metric.trend > 0 ? '↑' : '↓'} {Math.abs(metric.trend)}%
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  
                  {/* Visualization Panel */}
                  <div className="space-y-6">
                    <motion.div
                      className="metric-card-v2 p-6"
                      key={activeMetric}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5 }}
                    >
                      <h4 className="text-lg font-bold mb-4 text-gray-300">
                        Monitoring {shareGroupMetrics[activeMetric].name}
                      </h4>
                      
                      <pre className="bg-gray-900/60 p-4 rounded-lg text-sm overflow-x-auto">
                        <code className="text-gray-300">{`// JMX MBean Query
ObjectName: kafka.consumer:type=share-group-coordinator-metrics,
            share-group-id=my-share-group

// Prometheus Query
kafka_consumer_share_group_${shareGroupMetrics[activeMetric].name.replace(/-/g, '_')}
{share_group_id="my-share-group"}

// Alert Rule
alert: HighProcessingLatency
expr: ${shareGroupMetrics[activeMetric].name} > ${shareGroupMetrics[activeMetric].value * 2}
for: 5m
labels:
  severity: warning`}</code>
                      </pre>
                    </motion.div>
                    
                    {/* Real-time Graph Simulation */}
                    <div className="metric-card-v2 p-6">
                      <h4 className="text-lg font-bold mb-4 text-gray-300">
                        Real-time Trend
                      </h4>
                      <div className="h-32 relative flex items-end">
                        {Array.from({ length: 20 }).map((_, i) => {
                          const height = 30 + Math.sin((time + i) * 0.5) * 20 + Math.random() * 10;
                          return (
                            <motion.div
                              key={i}
                              className="bg-blue-500/60 mx-0.5 rounded-t"
                              style={{
                                width: '4%',
                                height: `${height}%`
                              }}
                              animate={{ opacity: [0.3, 0.8, 0.3] }}
                              transition={{ duration: 2, delay: i * 0.1, repeat: Infinity }}
                            />
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Comparison Phase */}
          <AnimatePresence>
            {phase === 'comparison' && (
              <motion.div
                className="w-full max-w-6xl mx-auto text-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <h2 className="scene-title text-4xl md:text-5xl mb-12">
                  Traditional vs Modern Metrics
                </h2>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
                  {[
                    { label: 'Consumer Lag', value: 50000, suffix: ' msgs', change: -20 },
                    { label: 'Unacked Age', value: 250, suffix: 'ms', change: -40 },
                    { label: 'Redelivery Rate', value: 0.3, suffix: '%', change: -60 },
                    { label: 'Lock Efficiency', value: 98.5, suffix: '%', change: 15 }
                  ].map((metric, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="metric-card-v2 p-6"
                    >
                      <h3 className="text-sm text-gray-400 mb-2">{metric.label}</h3>
                      <div className="metric-value text-2xl md:text-3xl mb-2">
                        {metric.value}{metric.suffix}
                      </div>
                      <div className={`text-sm font-bold ${
                        metric.change > 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {metric.change > 0 ? '↑' : '↓'} {Math.abs(metric.change)}%
                      </div>
                    </motion.div>
                  ))}
                </div>
                
                <motion.p
                  className="text-xl md:text-2xl text-gray-300"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  Share Groups provide <span className="text-green-400 font-bold">10x</span> more granular insights
                </motion.p>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Revelation Phase */}
          <AnimatePresence>
            {phase === 'revelation' && (
              <motion.div
                className="text-center max-w-4xl"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, type: "spring" }}
              >
                <motion.h2
                  className="scene-title text-5xl md:text-7xl mb-8"
                  animate={{
                    color: ['#3b82f6', '#10b981', '#f59e0b', '#3b82f6']
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  Metrics That Matter
                </motion.h2>
                <p className="text-xl md:text-3xl text-gray-300 leading-relaxed">
                  Stop measuring what's easy.<br />
                  Start measuring what's <span className="text-green-400 font-bold">important</span>.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default MetricSpotlightScene;