import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import AnimatedMetricCounter from '../../../../components/AnimatedMetricCounter';
import ProgressiveReveal from '../../../../components/ProgressiveReveal';
import '../../../../styles/techflix-cinematic-v2.css';

const TradeOffsScene = ({ time = 0, duration = 12 }) => {
  // Phase calculation
  const phase = time < 2 ? 'hook' : 
                time < 5 ? 'problem' : 
                time < 10 ? 'exploration' : 'insight';
  
  const localTime = phase === 'hook' ? time : 
                   phase === 'problem' ? time - 2 : 
                   phase === 'exploration' ? time - 5 : time - 10;
  
  return (
    <div className="scene-container-v2">
      <div className="scene-content">
        <div className="flex flex-col items-center justify-center min-h-full py-12">
          
          {/* Hook Phase */}
          <AnimatePresence>
            {phase === 'hook' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1 }}
                className="text-center"
              >
                <h1 className="scene-title text-5xl md:text-7xl mb-4">
                  The Monitoring Paradox
                </h1>
                <motion.p 
                  className="scene-subtitle"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: localTime > 0.5 ? 1 : 0 }}
                  transition={{ duration: 0.5 }}
                >
                  What if everything you knew about metrics was wrong?
                </motion.p>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Problem Phase */}
          <AnimatePresence>
            {phase === 'problem' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-full max-w-4xl space-y-8"
              >
                <div className="text-center mb-8">
                  <h2 className="scene-title text-3xl md:text-4xl">Traditional Metrics</h2>
                  <p className="scene-subtitle">Built for a simpler time</p>
                </div>
                
                <ProgressiveReveal delay={0.5} stagger={0.3}>
                  <div className="alert-box p-6 border-red-500/30 bg-red-900/20">
                    <h3 className="text-xl font-bold text-red-400 mb-3">The Limitations</h3>
                    <ul className="space-y-2 text-gray-300">
                      <li>• Consumer lag only tells part of the story</li>
                      <li>• Partition-based metrics miss the bigger picture</li>
                      <li>• No visibility into message processing state</li>
                    </ul>
                  </div>
                </ProgressiveReveal>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Exploration Phase */}
          <AnimatePresence>
            {phase === 'exploration' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-full max-w-6xl space-y-12"
              >
                <motion.h2 
                  className="scene-title text-4xl md:text-5xl text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.8 }}
                >
                  Consumer Groups vs Share Groups
                </motion.h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Consumer Groups */}
                  <motion.div
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: localTime > 2 ? 1 : 0, x: localTime > 2 ? 0 : -50 }}
                    transition={{ duration: 0.8 }}
                    className="metric-card-v2 p-8"
                  >
                    <h3 className="text-2xl font-bold text-red-400 mb-6">Consumer Groups</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center py-2 border-b border-gray-700">
                        <span className="text-gray-400">Primary Metric:</span>
                        <span className="font-mono text-yellow-400">consumer_lag</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-gray-700">
                        <span className="text-gray-400">Granularity:</span>
                        <span className="text-white">Per partition</span>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="text-gray-400">Processing Model:</span>
                        <span className="text-white">Sequential</span>
                      </div>
                    </div>
                  </motion.div>
                  
                  {/* Share Groups */}
                  <motion.div
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: localTime > 2 ? 1 : 0, x: localTime > 2 ? 0 : 50 }}
                    transition={{ duration: 0.8 }}
                    className="metric-card-v2 p-8"
                  >
                    <h3 className="text-2xl font-bold text-green-400 mb-6">Share Groups</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center py-2 border-b border-gray-700">
                        <span className="text-gray-400">Primary Metric:</span>
                        <span className="font-mono text-green-400">records_unacked_age</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-gray-700">
                        <span className="text-gray-400">Granularity:</span>
                        <span className="text-white">Message-level</span>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="text-gray-400">Processing Model:</span>
                        <span className="text-white">Concurrent</span>
                      </div>
                    </div>
                  </motion.div>
                </div>
                
                {/* Animated Metric Comparison */}
                <motion.div 
                  className="grid grid-cols-2 gap-8"
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: localTime > 3 ? 1 : 0, y: localTime > 3 ? 0 : 50 }}
                  transition={{ duration: 0.8 }}
                >
                  <div className="text-center">
                    <h4 className="text-lg text-gray-400 mb-2">Traditional Lag</h4>
                    <AnimatedMetricCounter
                      value={localTime > 4 ? 15000 : 0}
                      suffix=" msgs"
                      className="metric-value text-5xl text-red-400"
                      duration={2000}
                    />
                  </div>
                  <div className="text-center">
                    <h4 className="text-lg text-gray-400 mb-2">Unacked Age</h4>
                    <AnimatedMetricCounter
                      value={localTime > 4 ? 250 : 0}
                      suffix=" ms"
                      className="metric-value text-5xl text-green-400"
                      duration={2000}
                    />
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Insight Phase */}
          <AnimatePresence>
            {phase === 'insight' && (
              <motion.div
                className="text-center space-y-6"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="scene-title text-5xl md:text-6xl">
                  The Paradigm Shift
                </h2>
                <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto">
                  From counting messages to measuring actual processing time.
                  From partition boundaries to true concurrent processing.
                </p>
                <motion.div
                  className="inline-block mt-8"
                  animate={{ 
                    boxShadow: [
                      '0 0 20px rgba(147, 51, 234, 0.5)',
                      '0 0 40px rgba(147, 51, 234, 0.8)',
                      '0 0 20px rgba(147, 51, 234, 0.5)'
                    ]
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <div className="metric-card-v2 px-8 py-4 bg-gradient-to-r from-purple-600/20 to-blue-600/20">
                    <p className="text-xl font-bold">It's time to evolve your metrics</p>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default TradeOffsScene;