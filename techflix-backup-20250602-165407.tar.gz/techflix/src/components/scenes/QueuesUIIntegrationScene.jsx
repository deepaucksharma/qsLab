import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import '../../styles/techflix-cinematic-v2.css';

const QueuesUIIntegrationScene = ({ time, duration }) => {
  const progress = (time / duration) * 100;
  const [selectedQueue, setSelectedQueue] = useState(null);
  const [metrics, setMetrics] = useState({
    depth: 0,
    oldestAge: 0,
    consumers: 0,
    rate: 0
  });

  // Queue data
  const queues = [
    {
      id: 'orders:share-processor',
      name: 'orders:share-processor',
      provider: 'kafka-sharegroup',
      depth: 342,
      oldestAge: 4.2,
      consumers: 8,
      rate: 1250,
      health: 'healthy'
    },
    {
      id: 'payments:share-validator',
      name: 'payments:share-validator',
      provider: 'kafka-sharegroup',
      depth: 789,
      oldestAge: 12.5,
      consumers: 5,
      rate: 890,
      health: 'warning'
    },
    {
      id: 'inventory:share-updater',
      name: 'inventory:share-updater',
      provider: 'kafka-sharegroup',
      depth: 156,
      oldestAge: 2.1,
      consumers: 12,
      rate: 2100,
      health: 'healthy'
    }
  ];

  // Animate metrics
  useEffect(() => {
    if (selectedQueue && time > 8) {
      const queue = queues.find(q => q.id === selectedQueue);
      if (queue) {
        const animProgress = Math.min((time - 8) / 3, 1);
        setMetrics({
          depth: Math.floor(queue.depth * animProgress),
          oldestAge: (queue.oldestAge * animProgress).toFixed(1),
          consumers: Math.floor(queue.consumers * animProgress),
          rate: Math.floor(queue.rate * animProgress)
        });
      }
    }
  }, [time, selectedQueue]);

  // Auto-select first queue
  useEffect(() => {
    if (time > 6 && !selectedQueue) {
      setSelectedQueue(queues[0].id);
    }
  }, [time, selectedQueue]);

  const showTitle = time > 0.5;
  const showDashboard = time > 2;
  const showQueues = time > 4;
  const showDetails = time > 6;
  const showChart = time > 10;
  const showAlerts = time > 14;

  return (
    <div className="scene-container-v2">
      <div className="scene-content">
        <div className="flex flex-col items-center justify-center min-h-full py-12">
          {/* Title */}
          <AnimatePresence>
            {showTitle && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.8 }}
                className="text-center mb-12"
              >
                <h1 className="scene-title">New Relic Queues & Streams UI</h1>
                <p className="scene-subtitle">Your Share Groups in Production</p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Dashboard Container */}
          <AnimatePresence>
            {showDashboard && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.5 }}
                className="metric-card-v2 overflow-hidden w-full max-w-6xl"
              >
                {/* Dashboard Header */}
                <div className="bg-gray-800/50 px-6 py-4 border-b border-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <h2 className="text-xl font-semibold text-white">Queues & Streams</h2>
                      <span className="px-3 py-1 bg-purple-600/50 text-purple-300 text-xs rounded-full">Live</span>
                    </div>
                    <div className="text-sm text-gray-400">Last updated: Just now</div>
                  </div>
                </div>

                <div className="p-6">
                  {/* Queue Cards Grid */}
                  <AnimatePresence>
                    {showQueues && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.5 }}
                        className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6"
                      >
                        {queues.map((queue, idx) => (
                          <motion.div
                            key={queue.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.1, duration: 0.5 }}
                            className={`bg-gray-800/40 rounded-lg p-4 border cursor-pointer transition-all duration-300 ${
                              selectedQueue === queue.id 
                                ? 'border-purple-500/50 shadow-lg shadow-purple-500/10' 
                                : 'border-gray-700 hover:border-gray-600'
                            }`}
                            onClick={() => setSelectedQueue(queue.id)}
                          >
                            {/* Queue Header */}
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <h3 className="font-semibold text-white text-sm">{queue.name}</h3>
                                <span className="text-xs text-gray-400">{queue.provider}</span>
                              </div>
                              <div className={`w-2 h-2 rounded-full ${
                                queue.health === 'healthy' ? 'bg-green-400' : 'bg-yellow-400'
                              }`} />
                            </div>

                            {/* Metrics */}
                            <div className="space-y-2">
                              <div className="flex justify-between text-xs">
                                <span className="text-gray-400">Depth</span>
                                <span className="text-white font-mono">{queue.depth}</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span className="text-gray-400">Oldest</span>
                                <span className="text-white font-mono">{queue.oldestAge}s</span>
                              </div>
                              <div className="flex justify-between text-xs">
                                <span className="text-gray-400">Consumers</span>
                                <span className="text-white font-mono">{queue.consumers}</span>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Selected Queue Details */}
                  <AnimatePresence>
                    {showDetails && selectedQueue && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ duration: 0.5 }}
                        className="bg-gray-800/40 rounded-lg p-6 border border-gray-700"
                      >
                        <h3 className="text-lg font-semibold text-white mb-4">
                          {queues.find(q => q.id === selectedQueue)?.name}
                        </h3>

                        {/* Metrics Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                          <div className="text-center">
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ delay: 0.1 }}
                              className="metric-value text-3xl mb-1 text-purple-400"
                            >
                              {metrics.depth}
                            </motion.div>
                            <div className="text-xs text-gray-400">Queue Depth</div>
                          </div>
                          <div className="text-center">
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ delay: 0.2 }}
                              className="metric-value text-3xl mb-1 text-blue-400"
                            >
                              {metrics.oldestAge}s
                            </motion.div>
                            <div className="text-xs text-gray-400">Oldest Message</div>
                          </div>
                          <div className="text-center">
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ delay: 0.3 }}
                              className="metric-value text-3xl mb-1 text-green-400"
                            >
                              {metrics.consumers}
                            </motion.div>
                            <div className="text-xs text-gray-400">Active Consumers</div>
                          </div>
                          <div className="text-center">
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ delay: 0.4 }}
                              className="metric-value text-3xl mb-1 text-orange-400"
                            >
                              {metrics.rate}
                            </motion.div>
                            <div className="text-xs text-gray-400">Messages/sec</div>
                          </div>
                        </div>

                        {/* Chart Area */}
                        <AnimatePresence>
                          {showChart && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ duration: 0.5 }}
                              className="bg-gray-900/40 rounded-lg p-4 h-40 flex items-center justify-center"
                            >
                              <svg className="w-full h-full">
                                <defs>
                                  <linearGradient id="depthGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                                    <stop offset="0%" stopColor="#9333ea" stopOpacity="0.6"/>
                                    <stop offset="100%" stopColor="#9333ea" stopOpacity="0.1"/>
                                  </linearGradient>
                                </defs>
                                {/* Simple area chart simulation */}
                                <path
                                  d={`M 0 100 ${Array(20).fill(null).map((_, i) => {
                                    const x = (i / 19) * 100;
                                    const y = 50 + Math.sin(i * 0.5 + time * 0.1) * 30;
                                    return `L ${x} ${y}`;
                                  }).join(' ')} L 100 100 Z`}
                                  fill="url(#depthGradient)"
                                  transform="scale(6, 1)"
                                />
                              </svg>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Alert Configuration */}
                  <AnimatePresence>
                    {showAlerts && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                        className="mt-6 alert-box p-4"
                      >
                        <div className="flex items-center">
                          <span className="text-2xl mr-3">⚠️</span>
                          <div>
                            <h4 className="font-semibold text-yellow-400">Alert Configured</h4>
                            <p className="text-sm text-gray-300">
                              Notify when queue depth exceeds 1000 for 5 minutes
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default QueuesUIIntegrationScene;