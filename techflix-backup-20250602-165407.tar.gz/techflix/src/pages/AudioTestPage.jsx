/**
 * Audio System Test Page
 * Tests all audio functionality with the streamlined V2 system
 */

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Volume2, VolumeX, Play, Square, Mic, MicOff } from 'lucide-react'
import { useAudio, useEpisodeAudio, useVoiceoverControls } from '@hooks/useAudio'
import audioManager from '@utils/audioManager'

const AudioTestPage = () => {
  const [log, setLog] = useState([])
  const [subtitle, setSubtitle] = useState('')
  
  // Audio hooks
  const systemAudio = useAudio()
  const voiceoverControls = useVoiceoverControls()
  const episodeAudio = useEpisodeAudio('s2e1')
  
  // Add log entry
  const addLog = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString()
    setLog(prev => [...prev, { timestamp, message, type }])
  }
  
  // Set up subtitle callback
  React.useEffect(() => {
    episodeAudio.setSubtitleCallback(setSubtitle)
  }, [episodeAudio])
  
  // System sound tests
  const systemSoundTests = [
    { name: 'Ta-Dum', action: () => systemAudio.playTaDum() },
    { name: 'Click', action: () => systemAudio.playClick() },
    { name: 'Hover', action: () => systemAudio.playHover() },
    { name: 'Success', action: () => systemAudio.playSuccess() },
    { name: 'Error', action: () => systemAudio.playError() },
    { name: 'Transition', action: () => systemAudio.playTransition() },
    { name: 'Scene Change', action: () => systemAudio.playSceneChange() },
    { name: 'Episode Start', action: () => systemAudio.playEpisodeStart() },
  ]
  
  // Voice-over tests
  const voiceoverTests = [
    { id: 'evolution-intro', name: 'Evolution Intro' },
    { id: 'evolution-birth', name: 'Kafka Birth' },
    { id: 'bottleneck-intro', name: 'Bottleneck Intro' },
    { id: 'sharegroups-revelation', name: 'Share Groups Revelation' },
    { id: 'impact-conclusion', name: 'Impact Conclusion' },
  ]
  
  // Effect tests
  const effectTests = [
    { name: 'tech-atmosphere', label: 'Tech Atmosphere (Ambient)' },
    { name: 'crisis-alarm', label: 'Crisis Alarm' },
    { name: 'breakthrough', label: 'Breakthrough' },
    { name: 'data-flow', label: 'Data Flow' },
    { name: 'success-chime', label: 'Success Chime' },
  ]
  
  // Get audio state
  const audioState = audioManager.getState()
  
  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-8">Audio System Test Page</h1>
        
        {/* Audio State */}
        <div className="bg-gray-800 p-6 rounded-lg mb-8">
          <h2 className="text-2xl font-semibold mb-4">Audio State</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p>System Sounds: {audioState.systemSounds.enabled ? '✅ Enabled' : '❌ Disabled'}</p>
              <p>System Volume: {Math.round(audioState.systemSounds.volume * 100)}%</p>
              <p>System Sounds Loaded: {audioState.systemSounds.loaded}</p>
            </div>
            <div>
              <p>Voiceovers: {audioState.voiceovers.enabled ? '✅ Enabled' : '❌ Disabled'}</p>
              <p>Voiceover Volume: {Math.round(audioState.voiceovers.volume * 100)}%</p>
              <p>Episode Loaded: {audioState.episode.loaded ? '✅ Yes' : '❌ No'}</p>
            </div>
          </div>
        </div>
        
        {/* Controls */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          {/* System Sound Controls */}
          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
              <Volume2 className="w-6 h-6" />
              System Sounds
            </h2>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => {
                    systemAudio.toggle()
                    addLog(`System sounds ${systemAudio.enabled ? 'disabled' : 'enabled'}`)
                  }}
                  className={`px-4 py-2 rounded ${
                    systemAudio.enabled ? 'bg-green-600' : 'bg-red-600'
                  }`}
                >
                  {systemAudio.enabled ? 'Enabled' : 'Disabled'}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={systemAudio.volume * 100}
                  onChange={(e) => systemAudio.setVolume(e.target.value / 100)}
                  className="flex-1"
                />
                <span>{Math.round(systemAudio.volume * 100)}%</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                {systemSoundTests.map(test => (
                  <button
                    key={test.name}
                    onClick={() => {
                      test.action()
                      addLog(`Playing: ${test.name}`)
                    }}
                    className="px-3 py-2 bg-blue-600 rounded hover:bg-blue-700 transition"
                  >
                    {test.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          {/* Voice-over Controls */}
          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
              <Mic className="w-6 h-6" />
              Voice-overs
            </h2>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => {
                    voiceoverControls.toggle()
                    addLog(`Voice-overs ${voiceoverControls.enabled ? 'disabled' : 'enabled'}`)
                  }}
                  className={`px-4 py-2 rounded ${
                    voiceoverControls.enabled ? 'bg-green-600' : 'bg-red-600'
                  }`}
                >
                  {voiceoverControls.enabled ? 'Enabled' : 'Disabled'}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={voiceoverControls.volume * 100}
                  onChange={(e) => voiceoverControls.setVolume(e.target.value / 100)}
                  className="flex-1"
                />
                <span>{Math.round(voiceoverControls.volume * 100)}%</span>
              </div>
              
              {episodeAudio.isLoading && (
                <p className="text-yellow-400">Loading episode audio...</p>
              )}
              
              {episodeAudio.error && (
                <p className="text-red-400">Error: {episodeAudio.error}</p>
              )}
              
              {episodeAudio.isLoaded && (
                <div className="space-y-2">
                  {voiceoverTests.map(test => (
                    <button
                      key={test.id}
                      onClick={() => {
                        episodeAudio.playVoiceover(test.id)
                        addLog(`Playing voiceover: ${test.name}`)
                      }}
                      className="w-full px-3 py-2 bg-purple-600 rounded hover:bg-purple-700 transition text-left"
                    >
                      {test.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Effects */}
        <div className="bg-gray-800 p-6 rounded-lg mb-8">
          <h2 className="text-2xl font-semibold mb-4">Sound Effects</h2>
          {episodeAudio.isLoaded ? (
            <div className="grid grid-cols-3 gap-3">
              {effectTests.map(test => (
                <button
                  key={test.name}
                  onClick={() => {
                    episodeAudio.playEffect(test.name)
                    addLog(`Playing effect: ${test.label}`)
                  }}
                  className="px-4 py-2 bg-indigo-600 rounded hover:bg-indigo-700 transition"
                >
                  {test.label}
                </button>
              ))}
              <button
                onClick={() => {
                  episodeAudio.stopAllEffects()
                  addLog('Stopped all effects')
                }}
                className="px-4 py-2 bg-red-600 rounded hover:bg-red-700 transition"
              >
                Stop All Effects
              </button>
            </div>
          ) : (
            <p className="text-gray-400">Load episode audio to test effects</p>
          )}
        </div>
        
        {/* Subtitles */}
        {subtitle && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-black/80 p-4 rounded-lg mb-8"
          >
            <h3 className="text-lg font-semibold mb-2">Current Subtitle:</h3>
            <p className="text-yellow-300">{subtitle}</p>
          </motion.div>
        )}
        
        {/* Activity Log */}
        <div className="bg-gray-800 p-6 rounded-lg">
          <h2 className="text-2xl font-semibold mb-4">Activity Log</h2>
          <div className="bg-black/50 p-4 rounded h-64 overflow-y-auto">
            {log.length === 0 ? (
              <p className="text-gray-500">No activity yet...</p>
            ) : (
              <div className="space-y-1 text-sm font-mono">
                {log.slice(-20).reverse().map((entry, index) => (
                  <div
                    key={index}
                    className={`${
                      entry.type === 'error' ? 'text-red-400' : 'text-green-400'
                    }`}
                  >
                    [{entry.timestamp}] {entry.message}
                  </div>
                ))}
              </div>
            )}
          </div>
          <button
            onClick={() => setLog([])}
            className="mt-4 px-4 py-2 bg-gray-700 rounded hover:bg-gray-600 transition"
          >
            Clear Log
          </button>
        </div>
      </div>
    </div>
  )
}

export default AudioTestPage