# Audio System Migration Guide

This guide helps you migrate from the old audio system to the streamlined implementation.

## Overview of Changes

### Path Changes
- **Old**: `/sounds/` → **New**: `/audio/`
- **Old**: `episodeAudioManager` → **New**: Integrated into `audioManager`
- **Old**: Separate managers → **New**: Single unified `audioManager`

### File Structure
```
OLD:
public/
├── sounds/
│   ├── voiceovers/
│   └── effects/

NEW:
public/
└── audio/
    ├── system/      (UI sounds: click, hover, ta-dum, etc.)
    ├── voiceovers/  (episode voice-overs)
    └── effects/     (episode sound effects)
```

## Component Migration

### 1. Update Imports

```javascript
// OLD
import audioManager from '@utils/audioManager'
import episodeAudioManager from '@utils/episodeAudioManager'
import { useAudio } from '@hooks/useAudio'

// NEW
import audioManager from '@utils/audioManager'
import { useAudio, useEpisodeAudio } from '@hooks/useAudio'
```

### 2. System Sounds (UI Effects)

```javascript
// OLD
audioManager.play('click', { volume: 0.3 })
audioManager.playClick()

// NEW (same API, cleaner implementation)
audioManager.playClick()
audioManager.playSystemSound('click', { volume: 0.3 })
```

### 3. Episode Audio Loading

```javascript
// OLD
episodeAudioManager.loadEpisode('s2e1')
episodeAudioManager.setSubtitleCallback(setSubtitle)

// NEW
audioManager.loadEpisodeAudio('s2e1')
audioManager.setSubtitleCallback(setSubtitle)
```

### 4. Voice-overs

```javascript
// OLD
episodeAudioManager.playVoiceover('segment-id')
audioManager.playVoiceOver('episodeId', 'sceneId') // deprecated
audioManager.playEpisodeVoiceoverSegment('segment-id') // newer but verbose

// NEW
audioManager.playVoiceover('segment-id', options)
```

### 5. Sound Effects

```javascript
// OLD
episodeAudioManager.playEffect('effect-name')
audioManager.playEpisodeEffect('effect-name')

// NEW
audioManager.playEffect('effect-name', options)
```

### 6. Cleanup

```javascript
// OLD
episodeAudioManager.cleanup()
audioManager.cleanupEpisodeAudio()

// NEW
audioManager.cleanupEpisodeAudio()
```

## React Hooks Migration

### Basic Audio Hook

```javascript
// OLD
const { playClick, playHover } = useAudio()

// NEW (same API)
const { playClick, playHover } = useAudio()
```

### Episode Audio Hook

```javascript
// NEW - Simplified episode management
const {
  isLoaded,
  isLoading,
  error,
  playVoiceover,
  playEffect,
  playAmbient,
  setSubtitleCallback
} = useEpisodeAudio('s2e1')

// Automatically handles loading and cleanup
```

### Voice-over Controls

```javascript
// OLD
audioManager.setVoiceOverEnabled(true)
audioManager.toggleVoiceOver()

// NEW
const { enabled, toggle, setEnabled } = useVoiceoverControls()
```

## Scene Component Example

### Before
```javascript
import episodeAudioManager from '@utils/episodeAudioManager'

useEffect(() => {
  episodeAudioManager.loadEpisode('s2e1').then(() => {
    episodeAudioManager.setSubtitleCallback(setSubtitle)
    episodeAudioManager.playAmbient('tech-atmosphere')
  })
  
  return () => {
    episodeAudioManager.stopAllEffects()
  }
}, [])

// In render
episodeAudioManager.playVoiceover(voiceoverId)
episodeAudioManager.playEffect(effectName)
```

### After
```javascript
import { useEpisodeAudio } from '@hooks/useAudio'

const {
  playVoiceover,
  playEffect,
  playAmbient,
  setSubtitleCallback
} = useEpisodeAudio('s2e1')

useEffect(() => {
  setSubtitleCallback(setSubtitle)
  if (isLoaded) {
    playAmbient('tech-atmosphere')
  }
}, [isLoaded])

// In render
playVoiceover(voiceoverId)
playEffect(effectName)
```

## Complete Example: EvolutionTimelineScene

See `EvolutionTimelineSceneV2.jsx` for a complete example of the migrated component.

Key changes:
1. Single audioManager import
2. Simplified loading with error handling
3. Cleaner API calls
4. Automatic cleanup

## Migration Checklist

- [ ] Update all imports to use `audioManager`
- [ ] Update hook imports to use `useAudio`
- [ ] Replace `episodeAudioManager` calls with `audioManager`
- [ ] Update method names (see API mapping above)
- [ ] Test audio playback
- [ ] Verify subtitles work
- [ ] Check cleanup on unmount
- [ ] Update any custom audio logic

## Benefits of Streamlined System

1. **Single Source of Truth**: One audio manager for everything
2. **Cleaner API**: Consistent method names
3. **Better Performance**: Optimized loading and caching
4. **Automatic Cleanup**: Hooks handle lifecycle
5. **Type Safety**: Better error handling
6. **Simplified State**: Less confusion about what's playing

## Troubleshooting

### Audio Not Playing
1. Check browser console for errors
2. Ensure paths use `/audio/` not `/sounds/`
3. Verify files exist in new locations
4. Check volume settings

### Subtitles Not Showing
1. Ensure `setSubtitleCallback` is called
2. Check voiceover metadata has text
3. Verify subtitle state is being updated

### Effects Not Loading
1. Check `sound-library.json` exists
2. Verify effect names match
3. Check file paths in library

## Need Help?

1. Check `audioManager.js` for API documentation
2. See example components for patterns
3. Check browser console for detailed logs